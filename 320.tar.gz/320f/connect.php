<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "320";
	$conn = new mysqli($servername, $username, $password,$db);
?>